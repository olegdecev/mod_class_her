﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace работа__для_информатики
{
    internal class Program
    {
        static void Main(string[] args)
        {
            dog myDog = new dog();
            myDog.tipo = "Labrador";
            myDog.age = 4;
            myDog.name = "Pushok";


            myDog.Dormir();
            myDog.Comer();
            myDog.ruff();

        }
    }
}
