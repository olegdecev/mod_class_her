﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace работа__для_информатики
{
    internal class dog : animal
    {
        public string name; 

        public void ruff()
        {
            Console.WriteLine("O cao chamado " + name + " latiu para o carteiro que se aproximava.");
        }

    }
}
