﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace работа__для_информатики
{
    internal class animal
    {
        public string tipo;
        public int age; 

        public void Comer()
        {
            Console.WriteLine("O " + tipo + " esta a pedir aquele pedaco de carne.");
        }

        public void Dormir()
        {
            Console.WriteLine("O " + tipo + " dorme...");
        }

    }
}
